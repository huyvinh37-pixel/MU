﻿MU Pixel — bản test

Nội dung
- Bản game hiện tại, gồm assets, rules.js, game.js và expansion.js.
- Di chuyển bằng nhấp chuột trái; nhấp quái để chọn và tiếp cận; nhấp vật phẩm để tự đi nhặt.

Chạy thử tại máy
Mở index.html bằng trình duyệt. Nếu trình duyệt chặn tải ảnh do chạy file trực tiếp, chạy máy chủ tĩnh trong thư mục này, ví dụ:
  npx wrangler pages dev .

Đưa bản test lên Cloudflare Pages
Tải thư mục này lên một dự án Cloudflare Pages hoặc dùng Direct Upload. Đây là bản tĩnh, không cần build command; thư mục gốc chứa index.html.
