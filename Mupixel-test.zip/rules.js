'use strict';
/* Data-derived classic subset. OpenMU SeasonSix skill data + Webzen class guide.
   Presentation timings, map layouts, item/drop economy and PvM tuning remain this remake's configuration. */
const SS6={
 classes:{
  dk:{name:'Dark Knight',vi:'Kỵ sĩ bóng đêm',stats:[28,20,25,10],hp:110,mp:20,hpLevel:2,mpLevel:.5,hpVit:3,mpEne:1,defDiv:3,speedDiv:15,ag:[.15,.2,.3,1],starter:['short','leather','shield'],skills:['attack','falling','twisting','deathstab','rageful'],color:'#d4b777'},
  dw:{name:'Dark Wizard',vi:'Phù thuỷ bóng đêm',stats:[18,18,15,30],hp:60,mp:60,hpLevel:1,mpLevel:2,hpVit:2,mpEne:2,defDiv:4,speedDiv:10,ag:[.2,.4,.3,.2],starter:['staff','robe','shield'],skills:['energy','fire','wave','lightning','teleport','evil'],color:'#aaa0e3'}
 },
 skills:{
  attack:{name:'Đánh thường',cls:'dk',mp:0,ag:0,energy:0,level:1,range:1.5,base:0,kind:'melee',icon:'⚔',color:'#e0e2c9',frames:8,impact:.46},
  falling:{name:'Falling Slash',cls:'dk',mp:9,ag:0,energy:0,level:1,range:3,base:0,kind:'melee',weapon:true,icon:'╱',color:'#badff1',frames:10,impact:.52},
  twisting:{name:'Twisting Slash',cls:'dk',mp:10,ag:10,energy:0,level:80,range:2,base:0,kind:'spin',book:10000,icon:'✺',color:'#a7d8ee',frames:12,impact:.42},
  deathstab:{name:'Death Stab',cls:'dk',mp:15,ag:12,energy:0,level:160,range:2,base:70,kind:'stab',book:25000,icon:'➶',color:'#a3e5dc',frames:10,impact:.55},
  rageful:{name:'Rageful Blow',cls:'dk',mp:25,ag:20,energy:0,level:170,range:3,base:60,kind:'slam',book:30000,icon:'♜',color:'#eab27b',frames:14,impact:.64},
  energy:{name:'Energy Ball',cls:'dw',mp:1,ag:0,energy:0,level:1,range:6,base:3,kind:'bolt',icon:'◉',color:'#a7cdfa',frames:9,impact:.48},
  fire:{name:'Fire Ball',cls:'dw',mp:3,ag:0,energy:40,level:1,range:6,base:8,kind:'fire',book:100,icon:'♨',color:'#f1a368',frames:10,impact:.5},
  wave:{name:'Power Wave',cls:'dw',mp:5,ag:0,energy:56,level:1,range:6,base:14,kind:'wave',book:250,icon:'≋',color:'#98d8b8',frames:10,impact:.46},
  lightning:{name:'Lightning',cls:'dw',mp:15,ag:0,energy:72,level:1,range:6,base:17,kind:'lightning',book:500,icon:'ϟ',color:'#b9c9ff',frames:10,impact:.45},
  teleport:{name:'Teleport',cls:'dw',mp:30,ag:0,energy:88,level:1,range:6,base:0,kind:'teleport',book:800,icon:'◇',color:'#afa2f4',frames:8,impact:.42},
  evil:{name:'Evil Spirit',cls:'dw',mp:90,ag:0,energy:220,level:1,range:7,base:45,kind:'spirits',book:4000,icon:'☄',color:'#d7b6ef',frames:14,impact:.4}
 },
 maps:{
  lorencia:{name:'Lorencia',sub:'Làng & ngoại ô',min:1,cost:0,image:'lorencia.webp',theme:'forest',safeX:660,spawn:[545,495],size:[1536,1024],hunt:'Lv.1–18',monsters:['spider','goblin','bull','skeleton'],blocks:[{x:0,y:0,w:530,h:355},{x:0,y:690,w:410,h:334},{x:1380,y:0,w:156,h:400},{x:1340,y:650,w:196,h:374}],description:'Làng rèn, đồng cỏ và đường vào hầm mộ.'},
  noria:{name:'Noria',sub:'Rừng tiên',min:1,cost:0,image:'noria.webp',theme:'forest',safeX:580,spawn:[500,485],size:[1536,1024],hunt:'Lv.3–18',monsters:['goblin','beetle','golem'],blocks:[{x:0,y:0,w:500,h:320},{x:0,y:750,w:360,h:274},{x:1400,y:0,w:136,h:1024}],description:'Rừng xanh, đom đóm và những bãi săn mới.'},
  devias:{name:'Devias',sub:'Miền tuyết',min:15,cost:1000,image:'devias.webp',theme:'snow',safeX:580,spawn:[500,505],size:[1536,1024],hunt:'Lv.15–35',monsters:['worm','ice','yeti'],blocks:[{x:0,y:0,w:500,h:330},{x:0,y:760,w:350,h:264},{x:1400,y:0,w:136,h:1024}],description:'Đồng tuyết với Ice Monster và Yeti. Cần chuẩn bị trang bị.'},
  dungeon:{name:'Dungeon',sub:'Hầm ngục',min:20,cost:1500,image:'dungeon.webp',theme:'stone',safeX:430,spawn:[340,510],size:[1536,1024],hunt:'Lv.20–45',monsters:['skeleton','elite','hellspider'],blocks:[{x:0,y:0,w:460,h:300},{x:0,y:790,w:340,h:234},{x:1420,y:0,w:116,h:1024}],description:'Hầm mộ với Elite Skeleton và Hell Spider. Quái mạnh hơn nhiều.'},
  losttower:{name:'Lost Tower',sub:'Tháp thất lạc',min:40,cost:5000,image:'losttower.webp',theme:'tower',safeX:700,spawn:[535,555],size:[1536,1024],hunt:'Lv.40–70',monsters:['shadow','cursedwizard','deathknight','gorgon'],blocks:[{x:900,y:145,w:310,h:275},{x:1120,y:745,w:340,h:260},{x:0,y:0,w:300,h:235}],description:'Tàn tích tháp cổ, đường đá và cầu vòm giữa màn sương tím.'},
  atlans:{name:'Atlans',sub:'Thành phố dưới biển',min:45,cost:6000,image:'atlans.webp',theme:'water',safeX:700,spawn:[535,565],size:[1536,1024],hunt:'Lv.43–74',monsters:['bahamut','vepar','valkyrie','lizardking'],blocks:[{x:900,y:90,w:390,h:370},{x:0,y:0,w:380,h:220},{x:1160,y:670,w:350,h:300},{x:0,y:800,w:300,h:224}],description:'Phế tích chìm dưới đáy biển, san hô phát sáng và thủy quái canh đường đến Tarkan.'},
  tarkan:{name:'Tarkan',sub:'Sa mạc hoang tàn',min:70,cost:9000,image:'tarkan.webp',theme:'desert',safeX:700,spawn:[535,555],size:[1536,1024],hunt:'Lv.72–93',monsters:['mutant','ironwheel','deathbeam'],blocks:[{x:0,y:0,w:370,h:440},{x:1220,y:585,w:300,h:380},{x:1450,y:0,w:86,h:350}],description:'Sa mạc khô cằn, vách đá và tàn tích giữa vùng săn quái cấp cao.'}
 },
 monsters:{
 spider:{name:'Spider',lv:2,hp:30,min:4,max:7,def:1,defRate:1,atkRate:8,xp:12,zen:12,kind:'spider',attack:1.8},
 goblin:{name:'Goblin',lv:3,hp:45,min:7,max:10,def:2,defRate:2,atkRate:13,xp:18,zen:16,kind:'goblin',attack:1.8},
 bull:{name:'Bull Fighter',lv:6,hp:100,min:15,max:20,def:6,defRate:6,atkRate:24,xp:40,zen:34,kind:'bull',attack:1.6},
 skeleton:{name:'Skeleton',lv:19,hp:525,min:65,max:70,def:22,defRate:22,atkRate:93,xp:180,zen:90,kind:'skeleton',attack:1.6},
 beetle:{name:'Beetle Monster',lv:10,hp:165,min:26,max:31,def:10,defRate:10,atkRate:44,xp:75,zen:48,kind:'beetle',attack:1.6},
 golem:{name:'Stone Golem',lv:18,hp:550,min:60,max:65,def:20,defRate:18,atkRate:80,xp:160,zen:85,kind:'golem',attack:1.8},
 worm:{name:'Worm',lv:20,hp:600,min:70,max:75,def:25,defRate:25,atkRate:100,xp:200,zen:100,kind:'worm',attack:1.6},
 ice:{name:'Ice Monster',lv:22,hp:685,min:80,max:85,def:27,defRate:27,atkRate:110,xp:230,zen:120,kind:'ice',attack:1.6},
 yeti:{name:'Yeti',lv:30,hp:900,min:95,max:100,def:40,defRate:40,atkRate:150,xp:390,zen:170,kind:'yeti',attack:1.8},
 elite:{name:'Elite Skeleton',lv:24,hp:740,min:85,max:90,def:30,defRate:30,atkRate:120,xp:270,zen:140,kind:'elite',attack:1.6},
 hellspider:{name:'Hell Spider',lv:40,hp:1600,min:130,max:135,def:60,defRate:47,atkRate:200,xp:650,zen:260,kind:'hellspider',attack:1.6},
 shadow:{name:'Shadow',lv:47,hp:2200,min:120,max:130,def:70,defRate:52,atkRate:240,xp:900,zen:260,kind:'shadow',attack:1.6},
 cursedwizard:{name:'Cursed Wizard',lv:54,hp:2800,min:140,max:150,def:85,defRate:58,atkRate:270,xp:1150,zen:300,kind:'cursedwizard',attack:1.7},
 deathknight:{name:'Death Knight',lv:62,hp:3600,min:165,max:180,def:105,defRate:64,atkRate:310,xp:1450,zen:350,kind:'deathknight',attack:1.5},
 gorgon:{name:'Death Gorgon',lv:64,hp:3900,min:180,max:195,def:115,defRate:68,atkRate:330,xp:1600,zen:380,kind:'gorgon',attack:1.8},
 bahamut:{name:'Bahamut',lv:43,hp:2100,min:115,max:125,def:72,defRate:50,atkRate:230,xp:850,zen:250,kind:'bahamut',attack:1.6},
 vepar:{name:'Vepar',lv:45,hp:2350,min:120,max:130,def:78,defRate:53,atkRate:245,xp:920,zen:270,kind:'bahamut',attack:1.7},
 valkyrie:{name:'Valkyrie',lv:46,hp:2550,min:130,max:145,def:82,defRate:55,atkRate:255,xp:980,zen:290,kind:'valkyrie',attack:1.5},
 lizardking:{name:'Lizard King',lv:70,hp:4400,min:185,max:200,def:125,defRate:72,atkRate:350,xp:1900,zen:420,kind:'lizardking',attack:1.5},
 mutant:{name:'Mutant',lv:72,hp:4700,min:195,max:210,def:135,defRate:75,atkRate:370,xp:2050,zen:440,kind:'mutant',attack:1.6},
 ironwheel:{name:'Iron Wheel',lv:80,hp:5400,min:215,max:230,def:150,defRate:82,atkRate:410,xp:2350,zen:480,kind:'ironwheel',attack:1.8},
 deathbeam:{name:'Death Beam Knight',lv:93,hp:6800,min:250,max:270,def:180,defRate:90,atkRate:470,xp:2900,zen:550,kind:'deathrider',attack:1.5}
 },
 stats(p){const c=this.classes[p.classId||'dk'];return {hp:Math.floor(c.hp+(p.level-1)*c.hpLevel+(p.stats[2]-c.stats[2])*c.hpVit),mp:Math.floor(c.mp+(p.level-1)*c.mpLevel+(p.stats[3]-c.stats[3])*c.mpEne),ag:Math.floor(p.stats.reduce((n,v,i)=>n+v*c.ag[i],0)),attackRate:Math.floor(p.level*5+p.stats[1]*1.5+p.stats[0]/4),defRate:Math.floor(p.stats[1]/3),speed:Math.floor(p.stats[1]/c.speedDiv)}},
 experience(l){return 10*(l+8)*(l-1)**2+(l>=257?1000*(l-247)*(l-256)**2:0)},
 hitChance(attack,def){return attack<=0?.05:Math.max(.05,Math.min(1,1-def/attack))},
 canLearn(p,id){const s=this.skills[id];return !!s&&p.classId===s.cls&&p.level>=s.level&&p.stats[3]>=s.energy},
 // The browser has no original MU BMD animation clip, so these are reconstructed timings.
 actionDuration(id,speed){const s=this.skills[id];return Math.max(.28,s.frames/(11+Math.min(180,speed)*.16))}
};
// MU client maps use a 256 x 256 coordinate grid. This remake renders each
// coordinate cell at 16 pixels, then remaps its earlier compact coordinates.
SS6.world={tiles:256,tilePixels:16,size:[4096,4096],version:1};
for(const map of Object.values(SS6.maps)){
 const scale=SS6.world.size[0]/1536, padY=256;
 map.sourceSize=[...map.size];
 map.spawn=[Math.round(map.spawn[0]*scale),Math.round((map.spawn[1]+padY)*scale)];
 map.safeX=Math.round(map.safeX*scale);
 map.blocks=map.blocks.map(b=>({x:Math.round(b.x*scale),y:Math.round((b.y+padY)*scale),w:Math.round(b.w*scale),h:Math.round(b.h*scale)}));
 map.size=[...SS6.world.size];map.tiles=[256,256];
}
if(typeof module!=='undefined')module.exports=SS6;
